import React, {useEffect, useState} from 'react';
import Select from "react-select";
import axios from "axios";
import {APIT_APTH, AUTH} from "../tools/Const";
import {toast} from "react-toastify";
import LocationModal from "./modals/LocationModal";
import NationModal from "./modals/NationModal";
import PositionModal from "./modals/PositionModal";
import LangModal from "./modals/LangModal";
import CompetencyModal from "./modals/CompetencyModal";
import UniversityModal from "./modals/UniversityModal";
import MgModal from "./modals/MgModal";
import AspModal from "./modals/AspModal";
import DcModal from "./modals/DcModal";
import AcModal from "./modals/AcModal";
import ConfilctModal from "./modals/ConfilctModal";

const AddEmployee = () => {
    const data = [
        {value: '1', label: 'Banana'},
        {value: 'chocolate1', label: 'Apple'},
        {value: 'chocolate13', label: 'Sugar'},
        {value: 'chocolate12', label: 'Cofe'},
        {value: 'chocolate2', label: 'Chocolate'},
        {value: 'chocolate2sd', label: 'Kiwi'},
    ]
    let bigData = new FormData()

    // modal
    const [locationModal, setLocationModal] = useState(false)
    const [locationModalSecond, setLocationModalSecond] = useState(false)
    const [propiskaModal, setPropiskaModal] = useState(false)
    const [propiskaModalSecond, setPropiskaModalSecond] = useState(false)
    const [nationModal, setNationModal] = useState(false)
    const [positionModal, setPositionModal] = useState(false)
    const [confilictModal, setConfilictModal] = useState(false)
    const [langModal, setLangModal] = useState(false)
    const [compModal, setCompModal] = useState(false)
    const [compModalSecond, setCompModalSecond] = useState(false)
    const [unModal1, setUnModal1] = useState(false)
    const [unModal2, setUnModal2] = useState(false)
    const [unModal3, setUnModal3] = useState(false)
    const [unModal4, setUnModal4] = useState(false)
    const [unModal5, setUnModal5] = useState(false)
    const [unModalSecond, setUnModalSecond] = useState(false)
    const [unModalThird, setUnModalThird] = useState(false)

    // info user
    const [users, setUsers] = useState([])
    const [usersValue, setUsersValue] = useState({})
    const [phoneNumber, setPhoneNumber] = useState("")
    const [birthday, setBirthday] = useState("")
    const [location, setLocation] = useState([])
    const [locationValue, setLocationValue] = useState("")
    const [sferaAkk, setSferaAkk] = useState("")
    const [dateWork, setDateWork] = useState("")
    const [adressPropiska, setAdressPropiska] = useState("")
    const [workExpresience, setWorkExpresience] = useState([])
    const [audit, setAudit] = useState("")
    const [reccomend, setReccomend] = useState(null)
    const [bachelorList, setBachelorList] = useState([])
    const [bachelorValue, setBachelorValue] = useState("")
    const [magstrList, setMagstrList] = useState([])
    const [magstrValue, setMagstrValue] = useState("")
    const [aspirantValue, setAspirantValue] = useState("")
    const [aspirantList, setAspirantList] = useState([])
    const [doctorantValue, setDoctorantValue] = useState("")
    const [doctorantList, setDoctorantList] = useState([])
    const [academikValue, setAcademikValue] = useState("")
    const [academikList, setAcademikList] = useState([])
    const [partiya, setPartiya] = useState("")
    const [bilet, setBilet] = useState("")
    const [nagrad, setNagrad] = useState("")
    const [workAdress, setWorkAdress] = useState("")
    const [factAdress, setFactAdress] = useState("")
    const [agreeCenter, setAgreeCenter] = useState("")
    const [lastWork, setLastWork] = useState("")
    const [status, setStatus] = useState([])
    const [statusValue, setStatusValue] = useState([])
    const [statusCenter, setStatusCenter] = useState(false)
    const [uvolen, setUvolen] = useState(false)
    const [pic, setPic] = useState(null)
    const [cv, setCv] = useState(null)
    const [propiskaValue, setpropiskaValue] = useState("")
    const [nation, setNation] = useState(null)
    const [nationValue, setNationValue] = useState("")
    const [getNation, setGetNation] = useState([])
    const [position, setPosition] = useState(null)
    const [positionValue, setPositionValue] = useState("")
    const [getPosition, setGetPosition] = useState([])
    const [confilict, setConfilict] = useState(null)
    const [confilictValue, setConfilictValue] = useState("")
    const [getConfilict, setGetConfilict] = useState([])
    const [lang, setLang] = useState(null)
    const [langValue, setLangValue] = useState("")
    const [getLang, setGetLang] = useState([])
    const [comp, setComp] = useState(null)
    const [compValue, setCompValue] = useState("")
    const [getComp, setGetComp] = useState([])

    const getUsersList = () => {
        axios.get(APIT_APTH + "users/list/", AUTH)
            .then(res => {
                setUsers(res.data)

            })
    }
    const getCityList = () => {
        axios.get(APIT_APTH + "apps/references/city/", AUTH)
            .then(res => {
                setLocation(res.data)
            })
    }
    const getNationData = () => {
        axios.get(APIT_APTH + "apps/references/nation/", AUTH)
            .then(res => {
                setGetNation(res.data)
            })
    }
    const getPositionData = () => {
        axios.get(APIT_APTH + "apps/references/position/", AUTH)
            .then(res => {
                setGetPosition(res.data)
            })
    }
    const getConfilictData = () => {
        axios.get(APIT_APTH + "apps/references/conflict_of_interest/", AUTH)
            .then(res => {
                setGetConfilict(res.data)
            })
    }
    const getLangData = () => {
        axios.get(APIT_APTH + "apps/references/foreign_languages/", AUTH)
            .then(res => {
                setGetLang(res.data)
            })
    }
    const getCompData = () => {
        axios.get(APIT_APTH + "apps/references/competency/", AUTH)
            .then(res => {
                setGetComp(res.data)
            })
    }
    const getStatusData = () => {
        axios.get(APIT_APTH + "apps/references/status/", AUTH)
            .then(res => {
                setStatus(res.data)
            })
    }
    const getBachelorData = () => {
        axios.get(APIT_APTH + "apps/references/bachelor/", AUTH)
            .then(res => {
                setBachelorList(res.data)
            })
    }
    const getMagstrData = () => {
        axios.get(APIT_APTH + "apps/references/magistracy/", AUTH)
            .then(res => {
                setMagstrList(res.data)
            })
    }
    const getAspirantData = () => {
        axios.get(APIT_APTH + "apps/references/phd/", AUTH)
            .then(res => {
                setAspirantList(res.data)
            })
    }
    const getDoctorantData = () => {
        axios.get(APIT_APTH + "apps/references/dr_science/", AUTH)
            .then(res => {
                setDoctorantList(res.data)
            })
    }
    const getAcademikData = () => {
        axios.get(APIT_APTH + "apps/references/academician/", AUTH)
            .then(res => {
                setAcademikList(res.data)
            })
    }
    const [photo123, setphoto123] = useState("/img/Camera.png");
    const uploadImg = (event) => {
        setphoto123(URL.createObjectURL(event.target.files[0]));
        setPic(event )
    }
    const uploadImg2 = (event) => {
        // bigData.append("resume",  event.target.value)
        setCv(event)
        document.getElementById("img3").style.display = "block";
        document.getElementById("img2").style.display = "none";
    }
    let langList=[]
    let compList=[]
    let statusList=[]
    let confilictList=[]


    // const sendData = (e, value) => {
    //     e.preventDefault()
    //
    //     if (
    //         usersValue.length !== 0
    //     ) {
    //         let sendNewData = {
    //             "address": adressPropiska,
    //             "phone_number": phoneNumber,
    //             "work": workAdress,
    //             "start_at_accreditation": sferaAkk,
    //             "partition": partiya,
    //             "military_special_rank": bilet,
    //             "graduate_by_government": nagrad,
    //             "birthday": birthday,
    //             "fact_live_place": factAdress,
    //             "last_work": lastWork,
    //             "work_xp": workExpresience,
    //             "audit_count": audit,
    //             "agree_status": statusCenter,
    //             "first_working_date": dateWork,
    //             "centre_agree": agreeCenter,
    //             "is_fired": uvolen,
    //             "user": usersValue?.value,
    //             "place_of_birth": propiskaValue?.value,
    //             "nation": nationValue.value,
    //             "bachelor": bachelorValue?.value,
    //             "magistracy": magstrValue?.value,
    //             "phd": aspirantValue?.value,
    //             "doctor_science": doctorantValue?.value,
    //             "academician": academikValue?.value,
    //             "work_position": positionValue?.value,
    //             "location": locationValue?.value,
    //             "recommendation": reccomend?.value,
    //             "tech_area": compValue ?  compValue?.map(item => compList?.push(item?.value)): "",
    //             "foreign_lang": langValue ? langValue?.map(item =>  langList.push(item?.value)) : "",
    //             "labor_activity": workExpresience,
    //             "photo_pic": pic,
    //             "about_family": null,
    //             "title_of_exp":  statusValue ? statusValue?.map(item =>  statusList.push(item?.value)) : "",
    //             "certificate": 1,
    //             "conflict_of_interest": confilictValue ? confilictValue?.map(item =>  confilictList.push(item?.value)) : ""
    //         }
    //         axios.post(APIT_APTH + "apps/employees/create/", sendNewData, {
    //                 headers: {
    //                     Authorization: "token " + localStorage.getItem("auth_token")
    //                 }
    //             }
    //         )
    //         toast.success("ok")
    //     } else {
    //         toast.error("warning")
    //     }
    // }

    const sendData2 = (e, value) => {
        e.preventDefault()

        bigData.append("photo_pic", pic.target.files[0])
        bigData.append("resume", cv.target.files[0])
        bigData.append("address", adressPropiska)
        bigData.append("phone_number", phoneNumber)
        bigData.append("work", workAdress)
        bigData.append("start_at_accreditation", sferaAkk)
        bigData.append("partition", partiya)
        bigData.append("military_special_rank", bilet)
        bigData.append("graduate_by_government", nagrad)
        bigData.append("birthday", birthday)
        bigData.append("fact_live_place", factAdress)
        bigData.append("last_work", lastWork)
        bigData.append("work_xp", workExpresience)
        bigData.append("agree_status", statusCenter)
        bigData.append("first_working_date", dateWork)
        bigData.append("centre_agree", agreeCenter)
        bigData.append("is_fired", uvolen)
        bigData.append("audit_count", audit)
        bigData.append("user", usersValue?.value)
        bigData.append("nation", nationValue?.value)
        bigData.append("place_of_birth", propiskaValue?.value)
        bigData.append("bachelor", bachelorValue?.value)
        bigData.append("magistracy", magstrValue?.value)
        bigData.append("phd", aspirantValue?.value)
        bigData.append("doctor_science", doctorantValue?.value)
        bigData.append("academician", academikValue?.value)
        bigData.append("work_position", positionValue?.value)
        bigData.append("location", locationValue?.value)
        bigData.append("recommendation", reccomend?.value)
        // bigData.append("labor_activity",  workExpresience)
        // bigData.append("title_of_exp", statusValueFake )
            langValue?.map((item) =>{
                bigData.append(`foreign_lang`, item.value)
            })
            compValue?.map((item) =>{
                bigData.append(`tech_area`, item.value)
            })
            statusValue?.map((item) =>{
                bigData.append(`title_of_exp    `, item.value)
            })
            confilictValue?.map((item) =>{
                bigData.append(`conflict_of_interest`, item.value)
            })
        axios.post(APIT_APTH + "apps/employees/create/", bigData, {
                    headers: {
                        Authorization: "token " + localStorage.getItem("auth_token")
                    }
                }
            )
            toast.success("ok")
    }

    useEffect(() => {
        getUsersList()
        getCityList()
        getNationData()
        getPositionData()
        getConfilictData()
        getLangData()
        getCompData()
        getBachelorData()
        getAcademikData()
        getMagstrData()
        getDoctorantData()
        getAspirantData()
        getStatusData()
    }, []);

    return (
        <div className="add-employee">
            <div className="container">
                <h2 className="open-sans-bold pt-5 mb-4">Добавить Сотрудник</h2>
                <form className="row" onSubmit={sendData2}>
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Аккаунт <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative  ">
                                <Select
                                    options={users?.map(item => {
                                        return {value: item.id, label: item.full_name}
                                    })}
                                    isClearable
                                    // required
                                    onChange={(e) => setUsersValue(e)}
                                    placeholder="Аккаунт"
                                />
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Номер телефона <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input onChange={(e) => setPhoneNumber(e.target.value)} type="text"
                                       placeholder="Номер телефона"/>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Дата рождения <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="date" onChange={(e) => setBirthday(e.target.value)}
                                       placeholder="Дата рождения"/>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Локация <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select isClearable
                                        placeholder="Локация"
                                        options={location?.map(item => {
                                            return {value: item.id, label: item.country.name + "-" + item.name}
                                        })}
                                        onChange={(e) => {
                                            setLocationValue(e)
                                        }}
                                />
                                <button className="add-btn" type="button" onClick={() => setLocationModal(true)}>
                                    {
                                        locationValue
                                            ?
                                            <img src="/img/edit.png" alt="+"/>
                                            :
                                            <img src="/img/plus.png" alt="+"/>
                                    }
                                </button>
                            </div>
                        </div>
                    </div>
                    <LocationModal
                        locationValue={locationValue}
                        setLocation={setLocation}
                        locationModal={locationModal}
                        setLocationModal={setLocationModal}
                        locationModalSecond={locationModalSecond}
                        fieldName="Локация"
                        setLocationModalSecond={setLocationModalSecond}
                        data={data}
                        setLoaction={setLocation}
                    />
                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Начало деятельности в сфере
                                аккредитации <span className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="date" onChange={(e) => setSferaAkk(e.target.value)}
                                       placeholder="Начало деятельности в сфере аккредитации"/>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Дата первого устройства на работу <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="date" onChange={(e) => setDateWork(e.target.value)}
                                       placeholder="Дата первого устройства на работ"/>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Адрес прописки по паспорту <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select isClearable
                                        placeholder="Адрес прописки по паспорту"
                                        options={location?.map(item => {
                                            return {value: item.id, label: item.country.name + "-" + item.name}
                                        })}
                                        onChange={(e) => {
                                            setpropiskaValue(e)
                                        }}
                                />
                                <button type="button" className="add-btn" onClick={() => setPropiskaModal(true)}>
                                    {
                                        propiskaValue
                                            ?
                                            <img src="/img/edit.png" alt="+"/>
                                            :
                                            <img src="/img/plus.png" alt="+"/>
                                    }
                                </button>
                            </div>
                        </div>
                    </div>
                    <LocationModal
                        locationValue={propiskaValue}
                        fieldName="Адрес прописки по паспорту"
                        locationModal={propiskaModal}
                        setLocationModal={setPropiskaModal}
                        locationModalSecond={propiskaModalSecond}
                        setLocationModalSecond={setPropiskaModalSecond}
                        data={data}
                        setLoaction={setLocation}
                    />
                    <div className="col-md-4 my-form-groups">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Национальность <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select
                                    options={getNation?.map(item => {
                                        return {value: item.id, label: item.name}
                                    })}
                                    isClearable
                                    defaultValue={nation}
                                    placeholder="Национальность"
                                    onChange={(e) => {
                                        setNationValue(e)
                                    }}/>
                                <button className="add-btn"
                                        type="button"
                                        onClick={() => setNationModal(true)}>
                                    {
                                        nationValue
                                            ?
                                            <img src="/img/edit.png" alt="+"/>
                                            :
                                            <img src="/img/plus.png" alt="+"/>
                                    }
                                </button>
                            </div>
                        </div>
                        <NationModal locationValue={nationValue}
                                     fieldName="Национальность"
                                     locationModal={nationModal}
                                     setLocationModal={setNationModal}
                                     setGetNation={setGetNation}
                                     getNation={getNation}
                                     setNation={setNation}
                                     nation={nation}
                        />
                    </div>
                    <div className="col-md-4 my-form-groups ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Должность <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select  options={getPosition?.map(item => {
                                            return {value: item.id, label: item.name}
                                        })}
                                        isClearable
                                        placeholder="Должность"
                                        onChange={(e) => {
                                            setPositionValue(e)
                                        }}/>
                                <button className="add-btn"
                                        type="button"
                                        onClick={() => setPositionModal(true)}>
                                    {
                                        positionValue
                                            ?
                                            <img src="/img/edit.png" alt="+"/>
                                            :
                                            <img src="/img/plus.png" alt="+"/>
                                    }
                                </button>
                            </div>
                        </div>
                    </div>
                    <PositionModal locationValue={positionValue}
                                 fieldName="Национальность"
                                 locationModal={positionModal}
                                 setLocationModal={setPositionModal}
                                 setGetPosition={setGetPosition}
                                 getPosition={getPosition}
                                 setPosition={setPosition}
                                 position={position}
                    />
                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Опыт работы </label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input onChange={(e) => setWorkExpresience(e.target.value)} type="number"
                                       placeholder="Опыт работы"/>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Количество проведенных аудитов</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input onChange={(e) => setAudit(e.target.value)} type="number"
                                       placeholder="Количество проведенных аудитов"/>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Кто рекомендовал <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative  ">
                                <Select
                                    options={users?.map(item => {
                                        return {value: item.id, label: item.full_name}
                                    })}
                                    isClearable
                                    onChange={(e) => setReccomend(e)}
                                    placeholder="Кто рекомендовал"
                                />
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Бакалавриат <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={bachelorList?.map(item => {
                                            return {value: item.id, label:    item.education.university.name + "-" + item.education.graduate + "   " + item.period  }
                                        })}
                                        isClearable
                                        onChange={(e) => setBachelorValue(e)}
                                        placeholder="Бакалавриат"/>
                                <button className="add-btn"
                                        type="button"
                                        onClick={() => setUnModal1(true)}
                                >
                                    {
                                        bachelorValue
                                            ?
                                            <img src="/img/edit.png" alt="+"/>
                                            :
                                            <img src="/img/plus.png" alt="+"/>
                                    }
                                </button>
                            </div>
                        </div>
                    </div>
                    <UniversityModal
                        unValue={bachelorValue}
                        setBachelorList={setBachelorList}
                        fieldName="Бакалавриат"
                        unModal={unModal1}
                        setUnModal={setUnModal1}
                        unModalSecond={unModalSecond}
                        setUnModalSecond={setUnModalSecond}
                        unModalThird={unModalThird}
                        setUnModalThird={setUnModalThird}
                        title="Добавить Бакалавриат"
                        titleSecond="Добавить ВУЗ Специальность"
                        titleThird="Наименование высшего учебного заведения"
                        url="bachelor"
                    />
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Магистратура </label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select isClearable
                                        options={magstrList?.map(item => {
                                            return {value: item.id, label:    item.education.university.name + "-" + item.education.graduate + "   " + item.period  }
                                        })}
                                        onChange={(e) => setMagstrValue(e)}
                                        placeholder="Магистратура"/>
                                <button className="add-btn"
                                        type="button"
                                        onClick={() => setUnModal2(true)}
                                >
                                    {
                                        magstrValue
                                            ?
                                            <img src="/img/edit.png" alt="+"/>
                                            :
                                            <img src="/img/plus.png" alt="+"/>                 }
                                </button>
                            </div>
                        </div>
                    </div>
                    <MgModal
                        unValue={magstrValue}
                        setBachelorList={setMagstrList}
                        fieldName="Магистратура"
                        unModal={unModal2}
                        setUnModal={setUnModal2}
                        unModalSecond={unModalSecond}
                        setUnModalSecond={setUnModalSecond}
                        unModalThird={unModalThird}
                        setUnModalThird={setUnModalThird}
                        title="Добавить магистратура"
                        titleSecond="Добавить ВУЗ Специальность"
                        titleThird="Наименование высшего учебного заведения"
                        url="magistracy"
                    />
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Аспирантура </label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select isClearable
                                        options={aspirantList?.map(item => {
                                            return {value: item.id, label:    item.education.university.name + "-" + item.education.graduate + "   " + item.period  }
                                        })}
                                        onChange={(e) => setAspirantValue(e)}
                                        placeholder="Аспирантура"/>
                                <button className="add-btn"
                                        type="button"
                                        onClick={() => setUnModal3(true)}
                                >
                                    {
                                        aspirantValue
                                            ?
                                            <img src="/img/edit.png" alt="+"/>
                                            :
                                            <img src="/img/plus.png" alt="+"/>
                                    }
                                </button>
                            </div>
                        </div>
                    </div>
                    <AspModal
                        unValue={aspirantValue}
                        setBachelorList={setAspirantList}
                        fieldName="Аспирантура"
                        unModal={unModal3}
                        setUnModal={setUnModal3}
                        unModalSecond={unModalSecond}
                        setUnModalSecond={setUnModalSecond}
                        unModalThird={unModalThird}
                        setUnModalThird={setUnModalThird}
                        title="Добавить aспирантура"
                        titleSecond="Добавить ВУЗ Специальность"
                        titleThird="Наименование высшего учебного заведения"
                        url="phd"
                    />
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Докторантура </label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={doctorantList?.map(item => {
                                            return {value: item.id, label:    item.education.university.name + "-" + item.education.graduate + "   " + item.period  }
                                        })}
                                        onChange={(e) => setDoctorantValue(e)}
                                        isClearable
                                        placeholder="Докторантура "/>
                                        <button className="add-btn"
                                                type="button"
                                                onClick={() => setUnModal4(true)}
                                        >
                                            {
                                                doctorantValue
                                                    ?
                                                    <img src="/img/edit.png" alt="+"/>
                                                    :
                                                    <img src="/img/plus.png" alt="+"/>
                                            }
                                        </button>
                            </div>
                        </div>
                    </div>
                    <DcModal
                        unValue={doctorantValue}
                        setBachelorList={setDoctorantList}
                        fieldName="Докторантура"
                        unModal={unModal4}
                        setUnModal={setUnModal4}
                        unModalSecond={unModalSecond}
                        setUnModalSecond={setUnModalSecond}
                        unModalThird={unModalThird}
                        setUnModalThird={setUnModalThird}
                        title="Добавить докторантура"
                        titleSecond="Добавить ВУЗ Специальность"
                        titleThird="Наименование высшего учебного заведения"
                        url="dr_science"
                    />
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Академическое </label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={academikList?.map(item => {
                                            return {value: item.id, label:    item.education.university.name + "-" + item.education.graduate + "   " + item.period  }
                                        })}
                                        onChange={(e) => setAcademikValue(e)}
                                        isClearable
                                        placeholder="Академическое"/>
                                <button className="add-btn"
                                        type="button"
                                        onClick={() => setUnModal5(true)}
                                >
                                    {
                                        academikValue
                                            ?
                                            <img src="/img/edit.png" alt="+"/>
                                            :
                                            <img src="/img/plus.png" alt="+"/>
                                    }
                                </button>
                            </div>
                        </div>
                    </div>
                    <AcModal
                        unValue={academikValue}
                        setBachelorList={setAcademikList}
                        fieldName="Академическое"
                        unModal={unModal5}
                        setUnModal={setUnModal5}
                        unModalSecond={unModalSecond}
                        setUnModalSecond={setUnModalSecond}
                        unModalThird={unModalThird}
                        setUnModalThird={setUnModalThird}
                        title="Добавить"
                        titleSecond="Добавить ВУЗ Специальность"
                        titleThird="Наименование высшего учебного заведения"
                        url="academician"
                        status={5}
                    />
                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Партийность</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="text" onChange={(e) => setPartiya(e.target.value)}
                                       placeholder="Партийность"/>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Воинское (специальное) звание</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="text" onChange={(e) => setBilet(e.target.value)}
                                       placeholder="Воинское (специальное) звание"/>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Был ли удостоен государственных наград
                                (какой)</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="text" onChange={(e) => setNagrad(e.target.value)}
                                       placeholder="Был ли удостоен государственных наград (какой)"/>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Место жительство <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="text" onChange={(e) => setAdressPropiska(e.target.value)}
                                       placeholder="Место жительство"/>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Место работы <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="text" onChange={(e) => setWorkAdress(e.target.value)}
                                       placeholder="Место работы"/>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Адрес фактического проживания <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="text" onChange={(e) => setFactAdress(e.target.value)}
                                       placeholder="Адрес фактического проживания"/>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Договор, связанный с центром<span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="text" onChange={(e) => setAgreeCenter(e.target.value)}
                                       placeholder="Договор, связанный с центром"/>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Последнее место работы</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="text" onChange={(e) => setLastWork(e.target.value)}
                                       placeholder="Последнее место работы"/>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Компетенция (коды) </label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select isMulti
                                        options={getComp?.map(item => {
                                            return {value: item.id, label: item.name_code}
                                        })}
                                        onChange={(e) => setCompValue(e)}
                                        isClearable
                                        placeholder="Компетенция (коды)"/>
                                <button type="button"
                                        onClick={() => setCompModal(true)}
                                        className="add-btn">
                                    {
                                        compValue
                                            ?
                                            <img src="/img/edit.png" alt="+"/>
                                            :
                                            <img src="/img/plus.png" alt="+"/>
                                    }
                                </button>
                            </div>
                        </div>
                    </div>
                    <CompetencyModal
                        locationValue={compValue}
                        setLocation={setGetComp}
                        locationModal={compModal}
                        setLocationModal={setCompModal}
                        locationModalSecond={compModalSecond}
                        fieldName="Компетенция (коды)"
                        setLocationModalSecond={setCompModalSecond}
                        data={data}
                        setLoaction={setComp}
                    />
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Какими иностранными языками
                                владеет</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={getLang?.map(item => {
                                            return {value: item.id, label: item.lang}
                                        })}
                                        isClearable
                                        isMulti
                                        onChange={(e) =>{
                                            setLangValue(e)
                                        }}
                                        placeholder="Какими иностранными языками владеет"/>
                                <button className="add-btn"
                                        type="button"
                                        onClick={() => setLangModal(true)}
                                >
                                    {
                                        langValue[0]
                                            ?
                                            <img src="/img/edit.png" alt="+"/>
                                            :
                                            <img src="/img/plus.png" alt="+"/>
                                    }
                                </button>
                            </div>
                        </div>
                    </div>
                    <LangModal     locationValue={langValue}
                                   fieldName="Добавить Иностранные языки"
                                   locationModal={langModal}
                                   setLocationModal={setLangModal}
                                   setGetLang={setGetLang}
                                   getLang={getLang}
                                   setLang={setLang}
                                   lang={lang}
                    />
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Трудавая деятельность</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={data}
                                        isClearable
                                        placeholder="Трудавая деятельность"/>
                                <button className="add-btn"><img src="/img/plus.png" alt="+"/></button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Сертификаты и свидетельства</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={data}
                                        isClearable
                                        placeholder="Сертификаты и свидетельства"/>
                                <button className="add-btn"><img src="/img/plus.png" alt="+"/></button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Сведения о близких родтсвенниках</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={data}
                                        isClearable
                                        placeholder="Сведения о близких родтсвенниках"/>
                                <button className="add-btn"><img src="/img/plus.png" alt="+"/></button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Статус <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative  ">
                                <Select
                                    options={status?.map(item => {
                                        return {value: item.id, label: item.name}
                                    })}
                                    isClearable
                                    isMulti
                                    onChange={(e) => setStatusValue(e)}
                                    placeholder="Статус"
                                />
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Конфликт интересов</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={getConfilict?.map(item => {
                                            return {value: item.id, label: item.name + " " + item.reason}
                                        })}
                                        isClearable
                                        isMulti
                                        placeholder="Конфликт интересов"
                                        onChange={(e) => {
                                            setConfilictValue(e)
                                        }}/>
                                <button className="add-btn"
                                        type="button"
                                        onClick={() => setConfilictModal(true)}>
                                    {
                                        confilictValue
                                            ?
                                            <img src="/img/edit.png" alt="+"/>
                                            :
                                            <img src="/img/plus.png" alt="+"/>
                                    }
                                </button>
                            </div>
                        </div>
                    </div>
                    <ConfilctModal
                        locationValue={confilictValue}
                        fieldName="Конфликт интересов"
                        locationModal={confilictModal}
                        setLocationModal={setConfilictModal}
                        setGetPosition={setGetConfilict}
                        getPosition={getConfilict}
                        setPosition={setConfilict}
                        // position={confilict}
                    />
                    <div className="col-md-4 my-form-groups   d-flex flex-column  pt-4 justify-content-evenly">
                        <div className="my-check-style">
                            <input type="checkbox" onChange={() => setStatusCenter(!statusCenter)} id="dd245"/>
                            <label htmlFor="dd245" className="open-sans-semibold">Статус согласия с центром</label>
                        </div>
                        <div className="my-check-style">
                            <input id="dd235" onChange={() => setUvolen(!uvolen)} type="checkbox"/>
                            <label htmlFor="dd235" className="open-sans-semibold">Сотрудник был уволен</label>
                        </div>
                    </div>
                    <div className="col-md-12 my-form-groups   d-flex flex-row">
                        <div className="userPhoto">
                            <label htmlFor="userPhoto" id="img1"> <img src={photo123} alt=""/></label>
                            <input type="file" onChange={(e) => uploadImg(e)} id="userPhoto"/>
                            <p className="open-sans-semibold">Фотография</p>
                        </div>
                        <div className="userPhoto ">
                            <label htmlFor="userFile">< img id="img3" src="/img/check.png" style={{display: "none"}}
                                                            alt="file"/></label>
                            <label htmlFor="userFile"><img id="img2" src="/img/file.png" alt="file"/></label>
                            <input type="file" onChange={uploadImg2} id="userFile"/>
                            <p className="open-sans-semibold  ">Резюме</p>
                        </div>
                    </div>
                    <div className="col-md-12">
                        <button type="submit"
                            // onClick={sendData}
                                className="save-btn open-sans-semibold">
                            Сохранить
                        </button>
                    </div>

                </form>
            </div>
        </div>
    );
};

export default AddEmployee;