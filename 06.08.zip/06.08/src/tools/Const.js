export const APIT_APTH = "http://192.168.0.91:8000/"
export const AUTH = {headers: {Authorization: "token " + localStorage.getItem("auth_token")}}
export const SITE_LANG = "language"
