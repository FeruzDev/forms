import React, {useEffect, useState} from 'react';
import {APIT_APTH, AUTH, SITE_LANG} from "../tools/Const";
import axios from "axios";
import Select from "react-select";
import {getText} from "../locales";
import {Modal, ModalFooter, ModalHeader} from "reactstrap";

const ManagementSystemsCertification = () => {
    const [design, setDesign] = useState([])
    const [cert, setCert] = useState([])
    const [certValue, setCertValue] = useState(null)
    const [designValue, setDesignValue] = useState(null)
    const [locLang, setLocLang] = useState("ru")

    const [mainModal, setMainModal] = useState(false);

    const [toogle1, setToogle1] = useState(false);
    const [toogle2, setToogle2] = useState(false);
    const [toogle3, setToogle3] = useState(false);
    const [toogle4, setToogle4] = useState(false);
    const [toogle5, setToogle5] = useState(false);
    const [toogle6, setToogle6] = useState(false);
    const [toogle7, setToogle7] = useState(false);
    const [toogle8, setToogle8] = useState(false);
    const [srok, setSrok] = useState(null);

    const [akk, setAkk] = useState(false);
    const [prAkk, setPrAkk] = useState(false);
    const [rasAkk, setRasAkk] = useState(false);
    const [aktAkk, setAktAkk] = useState(false);
    const [sokAkk, setSokAkk] = useState(false);
    const [perAkk, setPerAkk] = useState(false);

    const [fullName, setFullName] = useState("");
    const [objectName, setObjectName] = useState("");
    const [statusOrgDate, setStatusOrgDate] = useState("");
    const [statusOrgNum, setStatusOrgNum] = useState("");
    const [yurAddress, setYurAddress] = useState("");
    const [factAddress, setFactAddress] = useState("");
    const [phoneNumber, setPhoneNumber] = useState("");
    const [siteName, setSiteName] = useState("");
    const [mail, setMail] = useState("");
    const [bank, setBank] = useState("");
    const [raschot, setRaschot] = useState("");
    const [soogu, setSoogu] = useState("");
    const [mfo, setMFO] = useState(null);
    const [oked, setOKED] = useState(null);
    const [inn, setInn] = useState("");
    const [yurPerson, setYurPerson] = useState("");
    const [phoneYurPerson, setPhoneYurPerson] = useState("");
    const [orgSer, setOrgSer] = useState("");
    const [phoneOrgSer, setPhoneOrgSer] = useState("");
    const [branchAdress, setBranchAdress] = useState("");
    const [phone_number, setphone_number] = useState("");
    const [full_name_head, setfull_name_head] = useState("");
    const [employees_count_in_branch, setemployees_count_in_branch] = useState("");
    const [key_activities, setkey_activities] = useState("");
    const [typeOf, setTypeOf] = useState("");
    const [serCount, setSerCount] = useState("");
    // const [certificate_number, setcertificate_number] = useState("");
    const [accreditation_date, setaccreditation_date] = useState("");
    const [foreign_accredit, setforeign_accredit] = useState("");
    const [orgName, setOrgName] = useState("");
    const [additional_offices, setadditional_offices] = useState("");
    const [consulting_info, setconsulting_info] = useState("");
    const [registration_number, setregistration_number] = useState("");
    const [certificate_validity_period_from, setcertificate_validity_period_from] = useState("");
    const [certificate_validity_period_to, setcertificate_validity_period_to] = useState("");

    const [file1, setFile1] = useState(null);
    const [file2, setFile2] = useState(null);
    const [file3, setFile3] = useState(null);
    const [file4, setFile4] = useState(null);

    let bigData = new FormData();

    const changeLang = (lang) => {
        localStorage.setItem(SITE_LANG, lang);
        setLocLang(lang)
    };

    const sendDataModal =()=>{
        setMainModal(true)
    };
    const sendData = () => {
        bigData.append("is_accreditation", akk);
        bigData.append("is_re_accreditation", prAkk);
        bigData.append("is_area_expansion_accreditation", rasAkk);
        bigData.append("is_actualization_accreditation", aktAkk);
        bigData.append("is_area_reduction_accreditation", sokAkk);
        bigData.append("is_upgrade_new_version", perAkk);
        bigData.append("legal_entity_full_name", fullName);
        bigData.append("full_name_accreditation_object", objectName);
        bigData.append("documentary_confirmation_int", statusOrgNum);
        bigData.append("documentary_confirmation_date", statusOrgDate);
        bigData.append("legal_address", yurAddress);
        bigData.append("actual_address", factAddress);
        bigData.append("phone", phoneNumber);
        bigData.append("web_site", siteName);
        bigData.append("email", mail);
        bigData.append("bank_name", bank);
        bigData.append("tin", inn);
        bigData.append("full_name_legal_person", yurPerson);
        bigData.append("phone_number_legal_person", phoneYurPerson);
        bigData.append("full_name_head_certification", orgSer);
        bigData.append("phone_head_certification", phoneOrgSer);

        bigData.append("is_branches", toogle1);
        if (toogle1) {
            bigData.append("branches[0]address", branchAdress);
            bigData.append("branches[0]phone_number", phone_number);
            bigData.append("branches[0]full_name_head", full_name_head);
            bigData.append("branches[0]employees_count_in_branch", employees_count_in_branch);
            bigData.append("branches[0]key_activities", key_activities);
        }

        bigData.append("is_commercial_activity", toogle2);
        if (toogle2) {
            bigData.append("type_of_commercial_activity", typeOf);
        }

        bigData.append("certification_activity", toogle3);
        if (toogle3) {
            bigData.append("certification_activity_count", serCount);
        }

        bigData.append("is_accredited_organ", toogle4);
        if (toogle4) {
            bigData.append("accredit_organ[0]name", orgName);
            // bigData.append("accredit_organ[0]certificate_number", certificate_number);
            bigData.append("accredit_organ[0]accreditation_date", accreditation_date);
            bigData.append("accredit_organ[0]foreign_accredit", foreign_accredit);
        }

        bigData.append("is_add_offices", toogle5);
        if (toogle5) {
            bigData.append("offices[0]additional_offices", additional_offices);
        }

        bigData.append("manage_system", srok);
        bigData.append("internal_audit", toogle6);
        bigData.append("leader_analyses", toogle7);

        bigData.append("is_consulting_company", toogle8);
        if (toogle8) {
            bigData.append("consulting_info", consulting_info);
        }
        bigData.append("registration_number", registration_number);
        bigData.append("certificate_validity_period_from", certificate_validity_period_from);
        bigData.append("certificate_validity_period_to", certificate_validity_period_to);
        bigData.append("project_scope_accreditation", file1?.target?.files[0]);
        bigData.append("quality_guide", file2?.target?.files[0]);
        bigData.append("management_system_docs", file3?.target?.files[0]);
        bigData.append("information_about", file4?.target?.files[0]);

        bigData.append("mfo", mfo);
        bigData.append("oked", oked);
        bigData.append("payment_acc", raschot);
        bigData.append("soogu", soogu);

        designValue?.map((item) => {
            bigData.append("standard_designation", item.value);
        });
        certValue?.map((item) => {
            bigData.append("standard_certification", item.value);
        });
        axios.post(APIT_APTH + "apps/application/send/9/", bigData, AUTH)
            .then(res => {
                console.log(res)
            })
    };
    const getCert = () => {
        axios.get(APIT_APTH + "apps/application/cert-standards/", AUTH)
            .then(res => {
                setCert(res.data)
            })
    };
    const getDesign = () => {
        axios.get(APIT_APTH + "apps/application/design-standards/", AUTH)
            .then(res => {
                setDesign(res.data)
            })
    };
    const checkFc = (e) => {
        console.log(e)
    };
    useEffect(() => {
        getDesign()
        getCert()
    }, []);

    return (
        <div className="ManagementSystemsCertification">

            <div className="navbar-main">
                <div className="container d-flex justify-content-between align-items-center h-100">
                    <div className="logo">
                        <img src="/img/logo12.svg" alt="" />
                    </div>
                    <div className="lang-btn">
                        <button
                            onClick={() => changeLang("ru")}
                            className={
                                !locLang ||
                                locLang === "ru"
                                    ? "active"
                                    : ""
                            }
                        >
                            Русский
                        </button>
                        <button
                            onClick={() => changeLang("uz")}
                            className={
                                locLang === "uz" ? "active" : ""
                            }
                        >
                            O'zbek
                        </button>
                    </div>
                </div>
            </div>
            <div className="container">
                <h2 className="open-sans-bold main-title">ЗАЯВКА <br/>
                    на аккредитацию органа по сертификации систем менеджмента
                    на соответствие требованиям O‘z DSt ISO/IEC 17021:2015
                </h2>
                <div className="big-box">
                    <h3 className="big-box-title open-sans-medium">
                        Заявка на (пожалуйста отметьте галочкой соответственный пункт)
                    </h3>
                    <div className="check-list">
                        <input type="checkbox" onChange={() => setAkk(!akk)} id="cur1"/>
                        <label htmlFor="cur1" className="open-sans-medium">Аккредитация</label>
                    </div>
                    <div className="check-list">
                        <input type="checkbox" onChange={() => setPrAkk(!prAkk)} id="cur2"/>
                        <label htmlFor="cur2" className="open-sans-medium">Пере-аккредитация</label>
                    </div>
                    <div className="check-list">
                        <input type="checkbox" onChange={() => setRasAkk(!rasAkk)} id="cur3"/>
                        <label htmlFor="cur3" className="open-sans-medium">Расширение области аккредитации </label>
                    </div>
                    <div className="check-list">
                        <input type="checkbox" onChange={() => setAktAkk(!aktAkk)} id="cur4"/>
                        <label htmlFor="cur4" className="open-sans-medium">Актуализация области аккредитации </label>
                    </div>
                    <div className="check-list">
                        <input type="checkbox" onChange={() => setSokAkk(!sokAkk)} id="cur5"/>
                        <label htmlFor="cur5" className="open-sans-medium">Сокращение области аккредитации </label>
                    </div>
                    <div className="check-list d-flex">
                        <input type="checkbox" onChange={() => setPerAkk(!perAkk)} id="cur6"/>
                        <label htmlFor="cur6" className="open-sans-medium">Переход на новую версию нормативного документа,
                            регламентирующего требования к оценке компетентности заявителя/объекта аккредитации </label>
                    </div>
                </div>
                <div className="big-box">
                    <h3 className="big-box-title open-sans-medium">
                        Информация о заявителе
                    </h3>
                    <div className="check-list">
                        <label className="open-sans-medium">Деятельность по сертификации:</label>
                        <label className="open-sans-medium" style={{marginLeft: "10px"}}>Cертификации систем
                            менеджмента</label>
                    </div>
                    <div className="many-checks">
                        <p className="open-sans-medium">Укажите обозначение стандарта аккредитации:</p>
                        <div className="lists mb-2">
                            <Select
                                isClearable
                                isMulti
                                placeholder="Укажите обозначение стандарта аккредитации"
                                options={design?.map((item) => {
                                    return {
                                        value: item.id,
                                        label: item.name
                                    };
                                })}
                                value={designValue}
                                onChange={(e) => {
                                    setDesignValue(e);
                                }}
                            />
                        </div>
                    </div>
                    <div className="many-checks">
                        <p className="open-sans-medium">Укажите стандарта сертификации:</p>
                        <div className="lists mb-2">
                            <Select
                                isClearable
                                isMulti
                                placeholder="Укажите обозначение стандарта аккредитации"
                                options={cert?.map((item) => {
                                    return {
                                        value: item.id,
                                        label: item.name
                                    };
                                })}
                                value={certValue}
                                onChange={(e) => {
                                    setCertValue(e);
                                }}
                            />
                        </div>
                    </div>
                    <div className="row">
                        <div className="my-input-groups col-md-6 pr-20">
                            <label className="open-sans-medium">Полное наименование юридического лица </label>
                            <input type="text" onChange={(e) => setFullName(e.target.value)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Полное название объекта аккредитации </label>
                            <input type="text" onChange={(e) => setObjectName(e.target.value)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Документальное подтверждение правового статуса
                                организации </label>
                            <div className="row">
                                <div className="col-md-6">
                                    <label className="open-sans-medium"> Hомер </label>
                                    <input type="text" onChange={(e) => setStatusOrgNum(e.target.value)}/>
                                </div>
                                <div className="col-md-6">
                                    <label className="open-sans-medium"> дата регистрации </label>
                                    <input type="date" onChange={(e) => setStatusOrgDate(e.target.value)}/>
                                </div>
                            </div>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Юридический адрес (номер офиса/здания, улица, город,
                                страна). </label>
                            <input type="text" onChange={(e) => setYurAddress(e.target.value)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Фактический адрес, если отличается от вышеуказанного
                                (номер офиса/здания, улица, город, страна). </label>
                            <input type="text" onChange={(e) => setFactAddress(e.target.value)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Номер телефона/факса </label>
                            <input type="text" onChange={(e) => setPhoneNumber(e.target.value)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Веб-сайт организации </label>
                            <input type="text" onChange={(e) => setSiteName(e.target.value)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Электронный адрес</label>
                            <input type="mail" onChange={(e) => setMail(e.target.value)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Банковские реквизиты</label>
                            <input type="text" onChange={(e) => setBank(e.target.value)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Расчетный счет</label>
                            <input type="text" onChange={(e) => setRaschot(e.target.value)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">МФО банка</label>
                            <input type="number" onChange={(e) => setMFO(e.target.value)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">ОКЭД банка</label>
                            <input type="number" onChange={(e) => setOKED(e.target.value)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">СООГУ банка</label>
                            <input type="number" onChange={(e) => setSoogu(e.target.value)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Идентификационный номер налогоплательщика (ИНН) </label>
                            <input type="text" onChange={(e) => setInn(e.target.value)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Ф.И.О. руководителя юридического лица. </label>
                            <input type="text" onChange={(e) => setYurPerson(e.target.value)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Номер телефона юр. лица</label>
                            <input type="text" onChange={(e) => setPhoneYurPerson(e.target.value)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Ф.И.О. руководителя органа сертификации </label>
                            <input type="text" onChange={(e) => setOrgSer(e.target.value)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Номер телефона органа</label>
                            <input type="text" onChange={(e) => setPhoneOrgSer(e.target.value)}/>
                        </div>

                    </div>
                </div>
                <div className="big-box">
                    <h2 className="big-box-title">
                        Информация об органе по сертификации
                    </h2>
                    <div className="toggle">
                        <label className="open-sans-medium">Имеются ли в органе по сертификации филиалы (в том числе за
                            рубежом)?
                            <div>
                                <button onClick={() => setToogle1(true)}
                                        className={toogle1 ? "open-sans-medium active" : "open-sans-medium"}>ДА
                                </button>
                                <button onClick={() => setToogle1(false)}
                                        className={toogle1 ? "open-sans-medium " : "open-sans-medium active"}>НЕТ
                                </button>
                            </div>
                        </label>
                    </div>
                    {
                        toogle1
                            ?
                            <div className="many-checks">
                                <p className="open-sans-medium">
                                    Если да, пожалуйста, заполните подраздел ниже:
                                </p>

                                <div className="row">
                                    <div className="my-input-groups col-md-6">
                                        <label className="open-sans-medium">Адрес/местоположение </label>
                                        <input onChange={(e) => setBranchAdress(e.target.value)} type="text"/>
                                    </div>
                                    <div className="my-input-groups col-md-6">
                                        <label className="open-sans-medium">Номер телефона </label>
                                        <input onChange={(e) => setphone_number(e.target.value)} type="text"/>
                                    </div>
                                    <div className="my-input-groups col-md-6">
                                        <label className="open-sans-medium">Ф.И.О. руководителя филиала
                                            лаборатории </label>
                                        <input onChange={(e) => setfull_name_head(e.target.value)} type="text"/>
                                    </div>
                                    <div className="my-input-groups col-md-6">
                                        <label className="open-sans-medium">Количество сотрудников в филиале органа по
                                            сертификации </label>
                                        <input onChange={(e) => setemployees_count_in_branch(e.target.value)}
                                               type="number"/>
                                    </div>
                                    <div className="my-input-groups col-md-12">
                                        <label className="open-sans-medium">Ключевые виды деятельности, проводимые в
                                            филиалах органа по сертификации</label>
                                        <input onChange={(e) => setkey_activities(e.target.value)} type="text"/>
                                    </div>
                                </div>
                            </div>
                            :
                            ""
                    }
                    <div className="toggle">
                        <label className="open-sans-medium">Занимается ли юридическое лицо, указанное выше, деятельностью
                            отличной от сертификации систем менеджмента?
                            <div>
                                <button onClick={() => setToogle2(true)}
                                        className={toogle2 ? "open-sans-medium active" : "open-sans-medium"}>ДА
                                </button>
                                <button onClick={() => setToogle2(false)}
                                        className={toogle2 ? "open-sans-medium " : "open-sans-medium active"}>НЕТ
                                </button>
                            </div>
                        </label>
                    </div>

                    {
                        toogle2
                            ?
                            <div className="many-checks">
                                <p className="open-sans-medium">
                                    Если да, пожалуйста, заполните подраздел ниже:
                                </p>

                                <div className="row">
                                    <div className="my-input-groups col-md-12">
                                        <label className="open-sans-medium">Если да то укажите вид деятельности</label>
                                        <input type="text" onChange={(e) => setTypeOf(e.target.value)}/>
                                    </div>

                                </div>
                            </div>
                            :
                            ""
                    }

                    <div className="toggle">
                        <label className="open-sans-medium">Проводилась ли какая-нибудь сертификационная деятельность в
                            заявленной области?
                            <div>
                                <button onClick={() => setToogle3(true)}
                                        className={toogle3 ? "open-sans-medium active" : "open-sans-medium"}>ДА
                                </button>
                                <button onClick={() => setToogle3(false)}
                                        className={toogle3 ? "open-sans-medium " : "open-sans-medium active"}>НЕТ
                                </button>
                            </div>
                        </label>
                    </div>
                    {
                        toogle3
                            ?
                            <div className="many-checks">
                                <p className="open-sans-medium">
                                    Если да, пожалуйста, заполните подраздел ниже:
                                </p>

                                <div className="row">
                                    <div className="my-input-groups col-md-12">
                                        <label className="open-sans-medium">Если да, то количество предоставленных
                                            сертификатов (для каждой заявленной области):</label>
                                        <input onChange={(e) => setSerCount(e.target.value)} type="number"/>
                                    </div>

                                </div>
                            </div>
                            :
                            ""
                    }
                    <div className="toggle">
                        <label className="open-sans-medium">Аккредитован ли орган по сертификации другим органом по
                            аккредитации, включая зарубежные органы по аккредитации?
                            <div>
                                <button onClick={() => setToogle4(true)}
                                        className={toogle4 ? "open-sans-medium active" : "open-sans-medium"}>ДА
                                </button>
                                <button onClick={() => setToogle4(false)}
                                        className={toogle4 ? "open-sans-medium " : "open-sans-medium active"}>НЕТ
                                </button>
                            </div>
                        </label>
                    </div>
                    {
                        toogle4
                            ?
                            <div className="many-checks">
                                <p className="open-sans-medium">
                                    Если да, пожалуйста, заполните подраздел ниже:
                                </p>

                                <div className="row">
                                    <div className="my-input-groups col-md-6">
                                        <label className="open-sans-medium">Укажите название органа</label>
                                        <input type="text" onChange={(e) => setOrgName(e.target.value)}/>
                                    </div>

                                    <div className="my-input-groups col-md-6">
                                        <label className="open-sans-medium">Дата аккредитации</label>
                                        <input type="date" onChange={(e) => setaccreditation_date(e.target.value)}/>
                                    </div>

                                    <div className="my-input-groups col-md-12">
                                        <label className="open-sans-medium">Какие из заявленных областей аккредитации
                                            аккредитованы другим (зарубежным) органом по аккредитации?</label>
                                        <input type="text" onChange={(e) => setforeign_accredit(e.target.value)}/>
                                    </div>

                                </div>
                            </div>
                            :
                            ""
                    }


                    <div className="toggle">
                        <label className="open-sans-medium">Имеются ли другие офисы/представительства?
                            <div>
                                <button onClick={() => setToogle5(true)}
                                        className={toogle5 ? "open-sans-medium active" : "open-sans-medium"}>ДА
                                </button>
                                <button onClick={() => setToogle5(false)}
                                        className={toogle5 ? "open-sans-medium " : "open-sans-medium active"}>НЕТ
                                </button>
                            </div>
                        </label>
                    </div>
                    {
                        toogle5
                            ?
                            <div className="many-checks">
                                <p className="open-sans-medium">
                                    Если да, пожалуйста, заполните подраздел ниже:
                                </p>

                                <div className="row">
                                    <div className="my-input-groups col-md-12">
                                        <label className="open-sans-medium">Укажите адрес</label>
                                        <input type="text" onChange={(e) => setadditional_offices(e.target.value)}/>
                                    </div>

                                </div>
                            </div>
                            :
                            ""
                    }
                    <div className="toggle-select">
                        <label className="open-sans-medium">Как давно в органе по сертификации внедрена система
                            менеджмента?
                            <div>
                                <button onClick={() => setSrok(0)}
                                        className={srok === 0 ? "open-sans-medium active" : "open-sans-medium"}>до 3-х
                                    месяцев
                                </button>
                                <button onClick={() => setSrok(1)}
                                        className={srok === 1 ? "open-sans-medium active" : "open-sans-medium"}>3-6
                                    месяца
                                </button>
                                <button onClick={() => setSrok(2)}
                                        className={srok === 2 ? "open-sans-medium active" : "open-sans-medium"}>более 6
                                    месяцев
                                </button>
                            </div>
                        </label>
                    </div>

                    <div className="toggle">
                        <label className="open-sans-medium">Был ли проведен внутренний аудит?
                            <div>
                                <button onClick={() => setToogle6(true)}
                                        className={toogle6 ? "open-sans-medium active" : "open-sans-medium"}>ДА
                                </button>
                                <button onClick={() => setToogle6(false)}
                                        className={toogle6 ? "open-sans-medium " : "open-sans-medium active"}>НЕТ
                                </button>
                            </div>
                        </label>
                    </div>
                    <div className="toggle">
                        <label className="open-sans-medium">Был ли проведен анализ со стороны руководства?
                            <div>
                                <button onClick={() => setToogle7(true)}
                                        className={toogle7 ? "open-sans-medium active" : "open-sans-medium"}>ДА
                                </button>
                                <button onClick={() => setToogle7(false)}
                                        className={toogle7 ? "open-sans-medium " : "open-sans-medium active"}>НЕТ
                                </button>
                            </div>
                        </label>
                    </div>
                </div>
                <div className="big-box">
                    <h2 className="big-box-title">
                        Дополнительная информация
                    </h2>

                    <div className="toggle">
                        <label className="open-sans-medium">Пользовался ли орган по сертификации консультациями по
                            подготовке к аккредитации?
                            <div>
                                <button onClick={() => setToogle8(true)}
                                        className={toogle8 ? "open-sans-medium active" : "open-sans-medium"}>ДА
                                </button>
                                <button onClick={() => setToogle8(false)}
                                        className={toogle8 ? "open-sans-medium " : "open-sans-medium active"}>НЕТ
                                </button>
                            </div>
                        </label>
                    </div>
                    {
                        toogle8
                            ?
                            <div className="many-checks">
                                <p className="open-sans-medium">
                                    Если да, пожалуйста, заполните подраздел ниже:
                                </p>

                                <div className="row">
                                    <div className="my-input-groups col-md-12">
                                        <label className="open-sans-medium"> Укажите наименование консалтинговой компании
                                            или Ф.И.О. консультанта</label>
                                        <input type="text" onChange={(e) => setconsulting_info(e.target.value)}/>
                                    </div>

                                </div>
                            </div>
                            :
                            ""
                    }
                </div>
                <div className="big-box">
                    <h2 className="big-box-title">
                        Информация о свидетельстве об аккредитации (если применимо)
                    </h2>
                    <div className="row">
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Регистрационный номер </label>
                            <input type="text" onChange={(e) => setregistration_number(e.target.value)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Срок действия свидетельства об аккредитации </label>
                            <div className="row d-flex">
                                <div className="date-field col-md-6  d-flex align-items-center">
                                    <label className="open-sans-medium">от</label>
                                    <input type="date"
                                           onChange={(e) => setcertificate_validity_period_from(e.target.value)}/>
                                </div>
                                <div className="date-field col-md-6 d-flex align-items-center">
                                    <label className="open-sans-medium">до </label>
                                    <input type="date"
                                           onChange={(e) => setcertificate_validity_period_to(e.target.value)}/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div className="big-box">
                    <h2 className="big-box-title">
                        Приложение к Заявке
                    </h2>
                    <div className="row">
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Проект области аккредитации </label>
                            <input type="file" onChange={(e) => setFile1(e)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Руководство по качеству (изменения к руководству по
                                качеству при расширении области аккредитации, при необходимости) </label>
                            <input type="file" onChange={(e) => setFile2(e)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Руководство по качеству (изменения к руководству по
                                качеству при расширении области аккредитации, при необходимости) </label>
                            <input type="file" onChange={(e) => setFile3(e)}/>
                        </div>
                        <div className="my-input-groups col-md-6">
                            <label className="open-sans-medium">Сведения о заявителе/объекте аккредитации</label>
                            <input type="file" onChange={(e) => setFile4(e)}/>
                        </div>
                    </div>
                </div>
                <div className="big-box justify-content-end d-flex footer-btn">
                    <button className="btn   open-sans-medium clear-btn">Очистить</button>
                    <button type="button" className="btn   open-sans-medium add-btn" onClick={sendDataModal}>Отправить</button>
                </div>
            </div>
            <Modal
                isOpen={mainModal}
                size="xl"
                toggle={() => setMainModal(false)}
                className="main-modal"
                dialogClassName="modal-100w"
            >
                <ModalHeader toggle={() => setMainModal(false)}>
                    ЗАЯВКА
                </ModalHeader>

                <div className="main-modal-content">
                    <div className="big-box">
                        <h3 className="big-box-title open-sans-medium">
                            Заявка на (пожалуйста отметьте галочкой соответственный пункт)
                        </h3>
                        <div className="check-list d-flex align-items-center">
                            {akk ? (
                                <img className="check-img" src="/img/bird.png" />
                            ) : (
                                <img className="check-img" src="/img/del.png" />
                            )}
                            <label className="open-sans-medium">Аккредитация</label>
                        </div>
                        <div className="check-list d-flex align-items-center">
                            {prAkk ? (
                                <img className="check-img" src="/img/bird.png" />
                            ) : (
                                <img className="check-img" src="/img/del.png" />
                            )}
                            <label className="open-sans-medium">Пере-аккредитация</label>
                        </div>
                        <div className="check-list d-flex align-items-center">
                            {rasAkk ? (
                                <img className="check-img" src="/img/bird.png" />
                            ) : (
                                <img className="check-img" src="/img/del.png" />
                            )}
                            <label className="open-sans-medium">Расширение области аккредитации </label>
                        </div>
                        <div className="check-list d-flex align-items-center">
                            {aktAkk ? (
                                <img className="check-img" src="/img/bird.png" />
                            ) : (
                                <img className="check-img" src="/img/del.png" />
                            )}
                            <label className="open-sans-medium">Актуализация области аккредитации </label>
                        </div>
                        <div className="check-list d-flex align-items-center">
                            {sokAkk ? (
                                <img className="check-img" src="/img/bird.png" />
                            ) : (
                                <img className="check-img" src="/img/del.png" />
                            )}
                            <label className="open-sans-medium">Сокращение области аккредитации </label>
                        </div>
                        <div className="check-list d-flex align-items-center">
                            {perAkk ? (
                                <img className="check-img" src="/img/bird.png" />
                            ) : (
                                <img className="check-img" src="/img/del.png" />
                            )}
                            <label className="open-sans-medium">Переход на новую версию нормативного документа,
                                регламентирующего требования к оценке компетентности заявителя/объекта аккредитации </label>
                        </div>
                    </div>
                    <div className="big-box">
                        <h3 className="big-box-title open-sans-medium">
                            Информация о заявителе
                        </h3>
                        <div className="check-list">
                            <label className="open-sans-medium">Деятельность по сертификации:</label>
                            <label className="open-sans-medium" style={{marginLeft: "10px"}}>Cертификации систем
                                менеджмента</label>
                        </div>
                        <div className="many-checks">
                            <p className="open-sans-medium">Укажите обозначение стандарта аккредитации:</p>
                            <div className="lists mb-2">
                                {
                                    designValue ?  designValue?.map(item =>(
                                            <span className="d-block">{item.label}</span>
                                        ))
                                        :
                                        "-"
                                }
                            </div>
                        </div>
                        <div className="many-checks">
                            <p className="open-sans-medium">Укажите стандарта сертификации:</p>
                            <div className="lists mb-2">
                                {
                                    certValue ?  certValue?.map(item =>(
                                        <span className="d-block">{item.label}</span>
                                    ))
                                        :
                                        "-"
                                }
                            </div>
                        </div>
                        <div className="row mt-4">
                            <div className="my-input-groups col-md-6 pr-20 m-0 justify-content-center">
                                <label className="open-sans-bold">Полное наименование юридического лица </label>
                                <span className="mb-3">{fullName ? fullName : "-"}</span>
                            </div>
                            <div className="my-input-groups col-md-6 m-0 justify-content-center">
                                <label className="open-sans-bold">Полное название объекта аккредитации </label>
                                <span className="mb-3">{objectName ? objectName : "-"}</span>
                            </div>
                            <div className="my-input-groups col-md-6 m-0 justify-content-center">
                                <label className="open-sans-bold">Документальное подтверждение правового статуса
                                    организации </label>
                                <div className="row">
                                    <div className="col-md-6 m-0 justify-content-center">
                                        <label className="open-sans-bold"> Hомер </label>
                                        <span className="mb-3">{statusOrgNum ? statusOrgNum : "-"}</span>
                                    </div>
                                    <div className="col-md-6 m-0 justify-content-center">
                                        <label className="open-sans-bold"> дата регистрации </label>
                                        <span className="mb-3">{statusOrgDate ? statusOrgDate : "-"}</span>
                                    </div>
                                </div>
                            </div>
                            <div className="my-input-groups col-md-6 m-0 justify-content-center">
                                <label className="open-sans-bold">Юридический адрес (номер офиса/здания, улица, город,
                                    страна). </label>
                                <span className="mb-3">{yurAddress ? yurAddress : "-"}</span>
                            </div>
                            <div className="my-input-groups col-md-6 m-0 justify-content-center">
                                <label className="open-sans-bold">Фактический адрес, если отличается от вышеуказанного
                                    (номер офиса/здания, улица, город, страна). </label>
                                <span className="mb-3">{factAddress ? factAddress : "-"}</span>
                            </div>
                            <div className="my-input-groups col-md-6 m-0 justify-content-center">
                                <label className="open-sans-bold">Номер телефона/факса </label>
                                <span className="mb-3">{phoneNumber ? phoneNumber : "-"}</span>
                            </div>
                            <div className="my-input-groups col-md-6 m-0 justify-content-center">
                                <label className="open-sans-bold">Веб-сайт организации </label>
                                <span className="mb-3">{siteName ? siteName : "-"}</span>
                            </div>
                            <div className="my-input-groups col-md-6 m-0 justify-content-center">
                                <label className="open-sans-bold">Электронный адрес</label>
                                <span className="mb-3">{mail ? mail : "-"}</span>
                            </div>
                            <div className="my-input-groups col-md-6 m-0 justify-content-center">
                                <label className="open-sans-bold">Банковские реквизиты</label>
                                <span className="mb-3">{bank ? bank : "-"}</span>
                            </div>
                            <div className="my-input-groups col-md-6 m-0 justify-content-center">
                                <label className="open-sans-bold">Расчетный счет</label>
                                <span className="mb-3">{raschot ? raschot : "-"}</span>
                            </div>
                            <div className="my-input-groups col-md-6 m-0 justify-content-center">
                                <label className="open-sans-bold">МФО банка</label>
                                <span className="mb-3">{mfo ? mfo : "-"}</span>
                            </div>
                            <div className="my-input-groups col-md-6 m-0 justify-content-center">
                                <label className="open-sans-bold">ОКЭД банка</label>
                                <span className="mb-3">{oked ? oked : "-"}</span>
                            </div>
                            <div className="my-input-groups col-md-6 m-0 justify-content-center">
                                <label className="open-sans-bold">СООГУ банка</label>
                                <span className="mb-3">{soogu ? soogu : "-"}</span>
                            </div>
                            <div className="my-input-groups col-md-6 m-0 justify-content-center">
                                <label className="open-sans-bold">Идентификационный номер налогоплательщика (ИНН) </label>
                                <span className="mb-3">{inn ? inn : "-"}</span>
                            </div>
                            <div className="my-input-groups col-md-6 m-0 justify-content-center">
                                <label className="open-sans-bold">Ф.И.О. руководителя юридического лица. </label>
                                <span className="mb-3">{yurPerson ? yurPerson : "-"}</span>
                            </div>
                            <div className="my-input-groups col-md-6 m-0 justify-content-center">
                                <label className="open-sans-bold">Номер телефона юр. лица</label>
                                <span className="mb-3">{phoneYurPerson ? phoneYurPerson : "-"}</span>
                            </div>
                            <div className="my-input-groups col-md-6 m-0 justify-content-center">
                                <label className="open-sans-bold">Ф.И.О. руководителя органа сертификации </label>
                                <span className="mb-3">{orgSer ? orgSer : "-"}</span>
                            </div>
                            <div className="my-input-groups col-md-6 m-0 justify-content-center">
                                <label className="open-sans-bold">Номер телефона органа</label>
                                <span className="mb-3">{phoneOrgSer ? phoneOrgSer : "-"}</span>
                            </div>

                        </div>
                    </div>
                    <div className="big-box">
                        <h2 className="big-box-title">
                            Информация об органе по сертификации
                        </h2>
                        <div className="toggle">
                            <label className="open-sans-bold">Имеются ли в органе по сертификации филиалы (в том числе за
                                рубежом)?
                                <div>
                                    {toogle1 ? (
                                        <img className="check-img-md" src="/img/bird.png" />
                                    ) : (
                                        <img className="check-img-md" src="/img/del.png" />
                                    )}

                                </div>
                            </label>
                        </div>
                        {
                            toogle1
                                ?
                                <div className="many-checks">
                                    <p className="open-sans-bold">
                                        Если да, пожалуйста, заполните подраздел ниже:
                                    </p>

                                    <div className="row">
                                        <div className="my-input-groups col-md-6">
                                            <label className="open-sans-bold">Адрес/местоположение </label>
                                            <span>{branchAdress ? branchAdress : "-"}</span>
                                        </div>
                                        <div className="my-input-groups col-md-6">
                                            <label className="open-sans-bold">Номер телефона </label>
                                            <span>{phone_number ? phone_number : "-"}</span>
                                        </div>
                                        <div className="my-input-groups col-md-6">
                                            <label className="open-sans-bold">Ф.И.О. руководителя филиала
                                                лаборатории </label>
                                            <span>{full_name_head ? full_name_head : "-"}</span>
                                        </div>
                                        <div className="my-input-groups col-md-6">
                                            <label className="open-sans-bold">Количество сотрудников в филиале органа по
                                                сертификации </label>
                                            <span>{employees_count_in_branch ? employees_count_in_branch : "-"}</span>
                                        </div>
                                        <div className="my-input-groups col-md-12">
                                            <label className="open-sans-bold">Ключевые виды деятельности, проводимые в
                                                филиалах органа по сертификации</label>
                                            <span>{key_activities ? key_activities : "-"}</span>
                                        </div>
                                    </div>
                                </div>
                                :
                                ""
                        }
                        <div className="toggle">
                            <label className="open-sans-bold">Занимается ли юридическое лицо, указанное выше, деятельностью
                                отличной от сертификации систем менеджмента?
                                <div>
                                    {toogle2 ? (
                                        <img className="check-img-md" src="/img/bird.png" />
                                    ) : (
                                        <img className="check-img-md" src="/img/del.png" />
                                    )}
                                </div>
                            </label>
                        </div>

                        {
                            toogle2
                                ?
                                <div className="many-checks">
                                    <p className="open-sans-bold">
                                        Если да, пожалуйста, заполните подраздел ниже:
                                    </p>

                                    <div className="row">
                                        <div className="my-input-groups col-md-12">
                                            <label className="open-sans-bold">Если да то укажите вид деятельности</label>
                                            <span>{typeOf ? typeOf : "-"}</span>
                                        </div>

                                    </div>
                                </div>
                                :
                                ""
                        }

                        <div className="toggle">
                            <label className="open-sans-bold">Проводилась ли какая-нибудь сертификационная деятельность в
                                заявленной области?
                                <div>
                                    {toogle3 ? (
                                        <img className="check-img-md" src="/img/bird.png" />
                                    ) : (
                                        <img className="check-img-md" src="/img/del.png" />
                                    )}
                                </div>
                            </label>
                        </div>
                        {
                            toogle3
                                ?
                                <div className="many-checks">
                                    <p className="open-sans-bold">
                                        Если да, пожалуйста, заполните подраздел ниже:
                                    </p>

                                    <div className="row">
                                        <div className="my-input-groups col-md-12">
                                            <label className="open-sans-bold">Если да, то количество предоставленных
                                                сертификатов (для каждой заявленной области):</label>
                                            <span>{serCount ? serCount : "-"}</span>
                                        </div>

                                    </div>
                                </div>
                                :
                                ""
                        }
                        <div className="toggle">
                            <label className="open-sans-bold">Аккредитован ли орган по сертификации другим органом по
                                аккредитации, включая зарубежные органы по аккредитации?
                                <div>
                                    {toogle4 ? (
                                        <img className="check-img-md" src="/img/bird.png" />
                                    ) : (
                                        <img className="check-img-md" src="/img/del.png" />
                                    )}
                                </div>
                            </label>
                        </div>
                        {
                            toogle4
                                ?
                                <div className="many-checks">
                                    <p className="open-sans-bold">
                                        Если да, пожалуйста, заполните подраздел ниже:
                                    </p>

                                    <div className="row">
                                        <div className="my-input-groups col-md-6">
                                            <label className="open-sans-bold">Укажите название органа</label>
                                            <span>{orgName ? orgName : "-"}</span>
                                        </div>

                                        <div className="my-input-groups col-md-6">
                                            <label className="open-sans-bold">Дата аккредитации</label>
                                            <span>{accreditation_date ? accreditation_date : "-"}</span>
                                        </div>

                                        <div className="my-input-groups col-md-12">
                                            <label className="open-sans-bold">Какие из заявленных областей аккредитации
                                                аккредитованы другим (зарубежным) органом по аккредитации?</label>
                                            <span>{foreign_accredit ? foreign_accredit : "-"}</span>
                                        </div>

                                    </div>
                                </div>
                                :
                                ""
                        }


                        <div className="toggle">
                            <label className="open-sans-bold">Имеются ли другие офисы/представительства?
                                <div>
                                    {toogle5 ? (
                                        <img className="check-img-md" src="/img/bird.png" />
                                    ) : (
                                        <img className="check-img-md" src="/img/del.png" />
                                    )}
                                </div>
                            </label>
                        </div>
                        {
                            toogle5
                                ?
                                <div className="many-checks">
                                    <p className="open-sans-bold">
                                        Если да, пожалуйста, заполните подраздел ниже:
                                    </p>

                                    <div className="row">
                                        <div className="my-input-groups col-md-12">
                                            <label className="open-sans-bold">Укажите адрес</label>
                                            <span>{additional_offices ? additional_offices : "-"}</span>
                                        </div>

                                    </div>
                                </div>
                                :
                                ""
                        }
                        <div className="toggle-select mt-4 mb-4">
                            <label className="open-sans-bold">Как давно в органе по сертификации внедрена система
                                менеджмента?
                                <div>
                                    {
                                        srok === 0 ?
                                            <button disabled
                                                    className= "open-sans-medium active">
                                                до 3-х месяцев
                                            </button>
                                            :
                                            srok === 1 ?
                                                <button disabled
                                                        className= "open-sans-medium active">
                                                    3-6 месяца
                                            </button> :
                                                srok === 3 ?
                                                    <button disabled
                                                            className= "open-sans-medium active">более 6
                                                        месяцев
                                                    </button>
                                                    :
                                                    <img className="check-img-md" src="/img/del.png" />

                                    }

                                </div>

                            </label>
                        </div>

                        <div className="toggle">
                            <label className="open-sans-bold">Был ли проведен внутренний аудит?
                                <div>
                                    {toogle6 ? (
                                        <img className="check-img-md" src="/img/bird.png" />
                                    ) : (
                                        <img className="check-img-md" src="/img/del.png" />
                                    )}
                                </div>
                            </label>
                        </div>
                        <div className="toggle">
                            <label className="open-sans-bold">Был ли проведен анализ со стороны руководства?
                                <div>
                                    {toogle7 ? (
                                        <img className="check-img-md" src="/img/bird.png" />
                                    ) : (
                                        <img className="check-img-md" src="/img/del.png" />
                                    )}
                                </div>
                            </label>
                        </div>
                    </div>
                </div>
                <ModalFooter>
                    <button
                        className="modal-cancel-btn"
                        onClick={() => setMainModal(false)}
                    >
                        {getText("cancel")}
                    </button>
                    <button onClick={sendData} className="modal-save-btn">
                        {getText("send")}
                    </button>
                </ModalFooter>
            </Modal>
        </div>
    );
};

export default ManagementSystemsCertification;