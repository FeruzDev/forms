import React, {useEffect, useState} from 'react';
import {Modal, ModalBody, ModalFooter, ModalHeader} from "reactstrap";
import Select from "react-select";
import axios from "axios";
import {APIT_APTH, AUTH} from "../../tools/Const";
import {toast} from "react-toastify";

const LocationModal = (props) => {
    const [getCity, setGetCity] = useState([])
    const [getCountry, setGetCountry] = useState([])
    const [country, setCountry] = useState("")
    const [city, setCity] = useState("")
    const [cityCountry, setCityCountry] = useState("")

    const addCountry = () => {
        axios.post(APIT_APTH + "apps/references/country/", {"name": country}, AUTH)
            .then(res => {
                getConutryList()
                props.setLocationModal(true)
                props.setLocationModalSecond(false)
            })
    }

    const createCity = () => {
        axios.post(APIT_APTH + "apps/references/city/",
            {
                "country_pk": cityCountry,
                "name": city},
            AUTH)
            .then(res => {
                getConutryList()
                getCityList()
                props.setLocationModal(false)
                props.setLocationModalSecond(false)

            })
            .catch(err =>{
                toast.error("Введите информацию")
            })
    }
    const getCityList = () => {
        axios.get(APIT_APTH + "apps/references/city/", AUTH)
            .then(res => {
                setGetCity(res.data)
                props.setLocation(res.data)
            })
    }
    const getConutryList = () => {
        axios.get(APIT_APTH + "apps/references/country/", AUTH)
            .then(res => {
                setGetCountry(res.data)
            })
    }
    useEffect(() => {
        getCityList()
        getConutryList()

    }, [])
    return (
            <>
                {/*Modals*/}
                <Modal  isOpen={props.locationModal} toggle={() => props.setLocationModal(false)}
                       className="modal-location">
                    <ModalHeader toggle={() => props.setLocationModal(false)}>{props.fieldName}</ModalHeader>
                    <ModalBody>
                        <div className="row">
                            <div className="col-md-12 my-form-groups   ">
                                <div className="my-select-style">
                                    <label htmlFor="dd2" className="open-sans-semibold">Страна </label>
                                    <div className="row flex-nowrap m-0 position-relative">
                                        <Select isClearable
                                                options={getCountry?.map(item => {
                                                    return {value: item.id, label: item.name}
                                                })}
                                                defaultValue={props.locationValue ? props.locationValue.name : ""}
                                                onChange={(e) => setCityCountry(e.value)}
                                                placeholder="Страна"/>
                                        <button className="add-btn"
                                                type="button"
                                                onClick={() => {
                                                    props.setLocationModal(false)
                                                    props.setLocationModalSecond(true)
                                                }}
                                        >
                                            <img src="/img/plus.png" alt="+"/>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div className="col-md-12 my-form-groups mt-3">
                                <div className="my-input-style">
                                    <label htmlFor="dd2" className="open-sans-semibold">Введите город</label>
                                    <div className="row flex-nowrap m-0 position-relative">
                                        <input type="text"
                                               placeholder="Введите город"
                                               onChange={(e) => setCity(e.target.value)}
                                        />

                                    </div>
                                </div>
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <button className="modal-save-btn" onClick={createCity}>Сохранить</button>
                    </ModalFooter>
                </Modal>
                <Modal isOpen={props.locationModalSecond} toggle={() => {
                    props.setLocationModalSecond(false)
                    props.setLocationModal(true)
                }} className="modal-location">
                    <ModalHeader toggle={() => props.setLocationModalSecond(false)}>{props.fieldName}</ModalHeader>
                    <ModalBody>
                        <div className="row">
                            <div className="col-md-12 my-form-groups mt-3">
                                <div className="my-input-style">
                                    <label htmlFor="dd2" className="open-sans-semibold">Страна</label>
                                    <div className="row flex-nowrap m-0 position-relative">
                                        <input onChange={(e) => setCountry(e.target.value)}
                                               type="text"
                                               placeholder="Страна"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </ModalBody>
                    <ModalFooter>
                        <button className="modal-save-btn" onClick={addCountry}>Сохранить</button>
                    </ModalFooter>
                </Modal>
            </>
        );
};

export default LocationModal;