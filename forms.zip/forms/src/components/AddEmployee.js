import React, {useEffect, useRef, useState} from 'react';
import MyInput from './MyInput'
import Select from "react-select";
import axios from "axios";
import {APIT_APTH, AUTH} from "../tools/Const";

import {Modal, ModalHeader, ModalBody, ModalFooter} from 'reactstrap';
import {toast} from "react-toastify";
import LocationModal from "./modals/LocationModal";
import MySelect from "./MySelect";
import MySelectName from "./MySelectName";
import NationModal from "./modals/NationModal";
import PositionModal from "./modals/PositionModal";
import LangModal from "./modals/LangModal";
// import {AvForm, AvField} from "availity-reactstrap-validation"

const AddEmployee = () => {
    const data = [
        {value: '1', label: 'Banana'},
        {value: 'chocolate1', label: 'Apple'},
        {value: 'chocolate13', label: 'Sugar'},
        {value: 'chocolate12', label: 'Cofe'},
        {value: 'chocolate2', label: 'Chocolate'},
        {value: 'chocolate2sd', label: 'Kiwi'},
    ]

    // modal
    const [locationModal, setLocationModal] = useState(false)
    const [locationModalSecond, setLocationModalSecond] = useState(false)
    const [propiskaModal, setPropiskaModal] = useState(false)
    const [propiskaModalSecond, setPropiskaModalSecond] = useState(false)
    const [nationModal, setNationModal] = useState(false)
    const [positionModal, setPositionModal] = useState(false)
    const [langModal, setLangModal] = useState(false)

    // info user
    const [users, setUsers] = useState([])
    const [usersValue, setUsersValue] = useState({})
    const [phoneNumber, setPhoneNumber] = useState("")
    const [birthday, setBirthday] = useState("")
    const [location, setLocation] = useState([])
    const [locationValue, setLocationValue] = useState("")
    const [sferaAkk, setSferaAkk] = useState("")
    const [dateWork, setDateWork] = useState("")
    const [adressPropiska, setAdressPropiska] = useState("")
    const [begin, setBegin] = useState("")
    const [job, setJob] = useState("")
    const [workExpresience, setWorkExpresience] = useState("")
    const [audit, setAudit] = useState("")
    const [reccomend, setReccomend] = useState("")
    const [bachelor, setBachelor] = useState("")
    const [magstr, setMagstr] = useState("")
    const [aspirant, setAspirant] = useState("")
    const [doctorant, setDoctorant] = useState("")
    const [academik, setAcademik] = useState("")
    const [partiya, setPartiya] = useState("")
    const [bilet, setBilet] = useState("")
    const [nagrad, setNagrad] = useState("")
    const [workAdress, setWorkAdress] = useState("")
    const [factAdress, setFactAdress] = useState("")
    const [agreeCenter, setAgreeCenter] = useState("")
    const [lastWork, setLastWork] = useState("")
    const [compen, setCompen] = useState("")
    const [workDel, setWorkDel] = useState("")
    const [status, setStatus] = useState("")
    const [info, setInfo] = useState("")
    const [certificat, setCertificat] = useState("")
    const [confilct, confilict] = useState("")
    const [statusCenter, setStatusCenter] = useState(false)
    const [uvolen, setUvolen] = useState(false)

    const [propiska, setPropiska] = useState(false)
    const [propiskaValue, setpropiskaValue] = useState("")

    const [nation, setNation] = useState(null)
    const [nationValue, setNationValue] = useState("")
    const [getNation, setGetNation] = useState([])

    const [position, setPosition] = useState(null)
    const [positionValue, setPositionValue] = useState("")
    const [getPosition, setGetPosition] = useState([])

    const [lang, setLang] = useState(null)
    const [langValue, setLangValue] = useState("")
    const [getLang, setGetLang] = useState([])

    const getUsersList = () => {
        axios.get(APIT_APTH + "users/list/", AUTH)
            .then(res => {
                setUsers(res.data)

            })
    }
    const getCityList = () => {
        axios.get(APIT_APTH + "apps/references/city/", AUTH)
            .then(res => {
                setLocation(res.data)
            })
    }
    const getNationData = () => {
        axios.get(APIT_APTH + "apps/references/nation/", AUTH)
            .then(res => {
                setGetNation(res.data)
            })
    }
    const getPositionData = () => {
        axios.get(APIT_APTH + "apps/references/position/", AUTH)
            .then(res => {
                setGetPosition(res.data)
            })
    }
    const getLangData = () => {
        axios.get(APIT_APTH + "apps/references/foreign_languages/", AUTH)
            .then(res => {
                setGetLang(res.data)
            })
    }

    const [photo123, setphoto123] = useState("/img/Camera.png");
    const uploadImg = (event) => {
        setphoto123(URL.createObjectURL(event.target.files[0]));
    }

    const uploadImg2 = (event) => {
        document.getElementById("img3").style.display = "block";
        document.getElementById("img2").style.display = "none";
    }
    const sendData = (e, value) => {
        e.preventDefault()
        console.log(usersValue)
        if (
            usersValue.length !== 0
        ) {
            let sendNewData = {
                "address": adressPropiska,
                "phone_number": phoneNumber,
                "work": workAdress,
                "start_at_accreditation": sferaAkk,
                "partition": partiya,
                "military_special_rank": bilet,
                "graduate_by_government": nagrad,
                "birthday": birthday,
                "fact_live_place": factAdress,
                "last_work": lastWork,
                "work_xp": workExpresience,
                "audit_count": audit,
                "agree_status": statusCenter,
                "first_working_date": dateWork,
                "centre_agree": agreeCenter,
                "is_fired": uvolen,
                "user": usersValue.value,
                "place_of_birth": propiskaValue.value,
                "nation": nationValue,
                "bachelor": 1,
                "magistracy": 1,
                "phd": 1,
                "doctor_science": doctorant,
                "academician": academik,
                "work_position": 1,
                "location": locationValue.value,
                "recommendation": 1,
                "tech_area": 1,
                "foreign_lang": langValue,
                "labor_activity": workExpresience,
                // "about_family": null,
                "title_of_exp": 1,
                "certificate": 1,
                "conflict_of_interest": [0]
            }

            axios.post(APIT_APTH + "apps/employees/create/", sendNewData, {
                    headers: {
                        Authorization: "token " + localStorage.getItem("auth_token")
                    }
                }
            )

            toast.success("ok")
        } else {
            toast.error("warning")
        }
    }

    useEffect(() => {
        getUsersList()
        getCityList()
        getNationData()
        getPositionData()
        getLangData()
    }, []);

    return (
        <div className="add-employee">
            <div className="container">
                <h2 className="open-sans-bold pt-5 mb-4">Добавить Сотрудник</h2>
                <form className="row" onSubmit={sendData}>
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Аккаунт <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative  ">
                                <Select
                                    options={users?.map(item => {
                                        return {value: item.id, label: item.full_name}
                                    })}
                                    isClearable
                                    // required
                                    onChange={(e) => setUsersValue(e)}
                                    placeholder="Аккаунт"
                                />

                            </div>
                        </div>
                    </div>


                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Номер телефона <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input onChange={(e) => setPhoneNumber(e.target.value)} type="text"
                                       placeholder="Номер телефона"/>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Дата рождения <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="date" onChange={(e) => setBirthday(e.target.value)}
                                       placeholder="Дата рождения"/>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Локация <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select isClearable
                                        placeholder="Локация"
                                        options={location?.map(item => {
                                            return {value: item.id, label: item.country.name + "-" + item.name}
                                        })}
                                        onChange={(e) => {
                                            setLocationValue(e)
                                        }}
                                />
                                <button className="add-btn" type="button" onClick={() => setLocationModal(true)}>
                                    {
                                        locationValue
                                            ?
                                            <img src="/img/edit.png" alt="+"/>
                                            :
                                            <img src="/img/plus.png" alt="+"/>

                                    }
                                </button>
                            </div>
                        </div>
                    </div>
                    <LocationModal
                        locationValue={locationValue}
                        setLocation={setLocation}
                        locationModal={locationModal}
                        setLocationModal={setLocationModal}
                        locationModalSecond={locationModalSecond}
                        fieldName="Локация"
                        setLocationModalSecond={setLocationModalSecond}
                        data={data}
                        setLoaction={setLocation}
                    />
                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Начало деятельности в сфере
                                аккредитации <span className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="date" onChange={(e) => setSferaAkk(e.target.value)}
                                       placeholder="Начало деятельности в сфере аккредитации"/>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Дата первого устройства на работу <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="date" onChange={(e) => setDateWork(e.target.value)}
                                       placeholder="Дата первого устройства на работ"/>
                            </div>
                        </div>
                    </div>


                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Адрес прописки по паспорту <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select isClearable
                                        placeholder="Адрес прописки по паспорту"
                                        options={location?.map(item => {
                                            return {value: item.id, label: item.country.name + "-" + item.name}
                                        })}
                                        onChange={(e) => {
                                            setpropiskaValue(e)
                                        }}
                                />
                                <button type="button" className="add-btn" onClick={() => setPropiskaModal(true)}>
                                    {
                                        propiskaValue
                                            ?
                                            <img src="/img/edit.png" alt="+"/>
                                            :
                                            <img src="/img/plus.png" alt="+"/>

                                    }
                                </button>
                            </div>
                        </div>
                    </div>
                    <LocationModal
                        locationValue={propiskaValue}
                        fieldName="Адрес прописки по паспорту"
                        locationModal={propiskaModal}
                        setLocationModal={setPropiskaModal}
                        locationModalSecond={propiskaModalSecond}
                        setLocationModalSecond={setPropiskaModalSecond}
                        data={data}
                        setLoaction={setLocation}
                    />
                    <div className="col-md-4 my-form-groups">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Национальность <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select
                                    options={getNation?.map(item => {
                                        return {value: item.id, label: item.name}
                                    })}
                                    isClearable
                                    defaultValue={nation}
                                    placeholder="Национальность"
                                    onChange={(e) => {
                                        setNationValue(e)
                                    }}/>
                                <button className="add-btn"
                                        type="button"
                                        onClick={() => setNationModal(true)}>
                                    {
                                        nationValue
                                            ?
                                            <img src="/img/edit.png" alt="+"/>
                                            :
                                            <img src="/img/plus.png" alt="+"/>

                                    }
                                </button>
                            </div>
                        </div>
                        <NationModal locationValue={nationValue}
                                     fieldName="Национальность"
                                     locationModal={nationModal}
                                     setLocationModal={setNationModal}
                                     setGetNation={setGetNation}
                                     getNation={getNation}
                                     setNation={setNation}
                                     nation={nation}
                        />
                    </div>

                    <div className="col-md-4 my-form-groups ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Должность <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select  options={getPosition?.map(item => {
                                            return {value: item.id, label: item.name}
                                        })}
                                        isClearable
                                        placeholder="Должность"
                                        onChange={(e) => {
                                            setPositionValue(e)
                                        }}/>
                                <button className="add-btn"
                                        type="button"
                                        onClick={() => setPositionModal(true)}>
                                    {
                                        positionValue
                                            ?
                                            <img src="/img/edit.png" alt="+"/>
                                            :
                                            <img src="/img/plus.png" alt="+"/>

                                    }
                                </button>
                            </div>
                        </div>
                    </div>
                    <PositionModal locationValue={positionValue}
                                 fieldName="Национальность"
                                 locationModal={positionModal}
                                 setLocationModal={setPositionModal}
                                 setGetPosition={setGetPosition}
                                 getPosition={getPosition}
                                 setPosition={setPosition}
                                 position={position}
                    />
                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Опыт работы </label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input onChange={(e) => setWorkExpresience(e.target.value)} type="number"
                                       placeholder="Опыт работы"/>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Количество проведенных аудитов</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input onChange={(e) => setAudit(e.target.value)} type="number"
                                       placeholder="Количество проведенных аудитов"/>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Кто рекомендовал <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative  ">
                                <Select
                                    options={users?.map(item => {
                                        return {value: item.id, label: item.full_name}
                                    })}
                                    isClearable
                                    onChange={(e) => setReccomend(e)}
                                    placeholder="Кто рекомендовал"
                                />
                            </div>
                        </div>
                    </div>


                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Бакалавриат <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={data}
                                        isClearable
                                        placeholder="Бакалавриат"/>
                                <button className="add-btn"><img src="/img/plus.png" alt="+"/></button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Магистратура </label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={data}
                                        isClearable
                                        placeholder="Магистратура"/>
                                <button className="add-btn"><img src="/img/plus.png" alt="+"/></button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Аспирантура </label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={data}
                                        isClearable
                                        placeholder="Аспирантура"/>
                                <button className="add-btn"><img src="/img/plus.png" alt="+"/></button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Докторантура </label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={data}
                                        isClearable
                                        placeholder="Докторантура "/>
                                <button className="add-btn"><img src="/img/plus.png" alt="+"/></button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Академическое </label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={data}
                                        isClearable
                                        placeholder="Академическое"/>
                                <button className="add-btn"><img src="/img/plus.png" alt="+"/></button>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Партийность</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="text" onChange={(e) => setPartiya(e.target.value)}
                                       placeholder="Партийность"/>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Воинское (специальное) звание</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="text" onChange={(e) => setBilet(e.target.value)}
                                       placeholder="Воинское (специальное) звание"/>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Был ли удостоен государственных наград
                                (какой)</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="text" onChange={(e) => setNagrad(e.target.value)}
                                       placeholder="Был ли удостоен государственных наград (какой)"/>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Место жительство <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="text" onChange={(e) => setAdressPropiska(e.target.value)}
                                       placeholder="Место жительство"/>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Место работы <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="text" onChange={(e) => setWorkAdress(e.target.value)}
                                       placeholder="Место работы"/>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Адрес фактического проживания <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="text" onChange={(e) => setFactAdress(e.target.value)}
                                       placeholder="Адрес фактического проживания"/>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Договор, связанный с центром<span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="text" onChange={(e) => setAgreeCenter(e.target.value)}
                                       placeholder="Договор, связанный с центром"/>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 my-form-groups">
                        <div className="my-input-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Последнее место работы</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <input type="text" onChange={(e) => setLastWork(e.target.value)}
                                       placeholder="Последнее место работы"/>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Компетенция (коды) </label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={data}
                                        isClearable
                                        placeholder="Компетенция (коды)"/>
                                <button className="add-btn"><img src="/img/plus.png" alt="+"/></button>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Какими иностранными языками
                                владеет</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={getLang?.map(item => {
                                            return {value: item.id, label: item.lang}
                                        })}
                                        isClearable
                                        // isMulti
                                        onChange={(e) =>{
                                            setLangValue(e)
                                        }}
                                        placeholder="Какими иностранными языками владеет"/>
                                <button className="add-btn"
                                        type="button"
                                        onClick={() => setLangModal(true)}
                                >
                                    <img src="/img/plus.png" alt="+"/>
                                </button>
                            </div>
                        </div>
                    </div>
                    <LangModal     locationValue={langValue}
                                   fieldName="Добавить Иностранные языки"
                                   locationModal={langModal}
                                   setLocationModal={setLangModal}
                                   setGetPosition={setGetLang}
                                   getPosition={getLang}
                                   setPosition={setLang}
                                   position={lang}
                    />
                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Трудавая деятельность</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={data}
                                        isClearable
                                        placeholder="Трудавая деятельность"/>
                                <button className="add-btn"><img src="/img/plus.png" alt="+"/></button>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Статус <span
                                className="with-star">*</span></label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={data}
                                        isClearable
                                        placeholder="Статус"/>
                                <button className="add-btn"><img src="/img/plus.png" alt="+"/></button>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Сведения о близких родтсвенниках</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={data}
                                        isClearable
                                        placeholder="Сведения о близких родтсвенниках"/>
                                <button className="add-btn"><img src="/img/plus.png" alt="+"/></button>
                            </div>
                        </div>
                    </div>


                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Сертификаты и свидетельства</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={data}
                                        isClearable
                                        placeholder="Сертификаты и свидетельства"/>
                                <button className="add-btn"><img src="/img/plus.png" alt="+"/></button>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 my-form-groups   ">
                        <div className="my-select-style">
                            <label htmlFor="dd2" className="open-sans-semibold">Конфликт интересов</label>
                            <div className="row flex-nowrap m-0 position-relative">
                                <Select options={data}
                                        isClearable
                                        placeholder="Конфликт интересов"/>
                                <button className="add-btn"><img src="/img/plus.png" alt="+"/></button>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-4 my-form-groups   d-flex flex-column  pt-4 justify-content-evenly">
                        <div className="my-check-style">
                            <input type="checkbox" onChange={() => setStatusCenter(!statusCenter)} id="dd245"/>
                            <label htmlFor="dd245" className="open-sans-semibold">Статус согласия с центром</label>
                        </div>
                        <div className="my-check-style">
                            <input id="dd235" onChange={() => setUvolen(!uvolen)} type="checkbox"/>
                            <label htmlFor="dd235" className="open-sans-semibold">Сотрудник был уволен</label>
                        </div>
                    </div>
                    <div className="col-md-12 my-form-groups   d-flex flex-row">
                        <div className="userPhoto">
                            <label htmlFor="userPhoto" id="img1"> <img src={photo123} alt=""/></label>
                            <input type="file" onChange={(e) => uploadImg(e)} id="userPhoto"/>
                            <p className="open-sans-semibold">Фотография</p>

                        </div>
                        <div className="userPhoto ">
                            <label htmlFor="userFile">< img id="img3" src="/img/check.png" style={{display: "none"}}
                                                            alt="file"/></label>
                            <label htmlFor="userFile"><img id="img2" src="/img/file.png" alt="file"/></label>
                            <input type="file" onChange={uploadImg2} id="userFile"/>
                            <p className="open-sans-semibold  ">Резюме</p>

                        </div>

                    </div>
                    <div className="col-md-12">
                        <button type="submit"
                            // onClick={sendData}
                                className="save-btn open-sans-semibold">
                            Сохранить
                        </button>
                    </div>

                </form>
            </div>
            {/*<AvForm onValidSubmit={sendData}>*/}
            {/*    <AvField name='user2'   />*/}
            {/*    <AvField name="fio"    />*/}
            {/*    <AvField name="pass"  />*/}

            {/*</AvForm>*/}
            {/*<>*/}
            {/*    /!*Modals*!/*/}
            {/*    <Modal isOpen={locationModal} toggle={() => setLocationModal(false)} className="modal-location">*/}
            {/*        <ModalHeader toggle={() => setLocationModal(false)}>Локация</ModalHeader>*/}
            {/*        <ModalBody>*/}
            {/*           <div className="row">*/}
            {/*               <div className="col-md-12 my-form-groups   ">*/}
            {/*                   <div className="my-select-style">*/}
            {/*                       <label htmlFor="dd2" className="open-sans-semibold">Страна </label>*/}
            {/*                       <div className="row flex-nowrap m-0 position-relative">*/}
            {/*                           <Select options={data}*/}
            {/*                                   isClearable*/}
            {/*                                   placeholder="Страна"/>*/}
            {/*                           <button className="add-btn"*/}
            {/*                                   type="button"*/}
            {/*                                   onClick={() => {*/}
            {/*                                       setLocationModal(false)*/}
            {/*                                       setLocationModalSecond(true)*/}
            {/*                                   }}*/}
            {/*                           >*/}
            {/*                               <img src="/img/plus.png" alt="+"/>*/}
            {/*                           </button>*/}
            {/*                       </div>*/}
            {/*                   </div>*/}
            {/*               </div>*/}

            {/*               <div className="col-md-12 my-form-groups">*/}
            {/*                   <div className="my-input-style">*/}
            {/*                       <label htmlFor="dd2" className="open-sans-semibold">Введите город</label>*/}
            {/*                       <div className="row flex-nowrap m-0 position-relative">*/}
            {/*                           <input type="text" placeholder="Введите город"/>*/}
            {/*                       </div>*/}
            {/*                   </div>*/}
            {/*               </div>*/}
            {/*           </div>*/}
            {/*        </ModalBody>*/}
            {/*        <ModalFooter>*/}
            {/*            <button className="modal-save-btn">Сохранить</button>*/}
            {/*        </ModalFooter>*/}
            {/*    </Modal>*/}
            {/*    <Modal isOpen={locationModalSecond} toggle={() => {*/}
            {/*        setLocationModalSecond(false)*/}
            {/*        setLocationModal(true)*/}
            {/*    }} className="modal-location">*/}
            {/*        <ModalHeader toggle={() => setLocationModalSecond(false)}>Локация</ModalHeader>*/}
            {/*        <ModalBody>*/}
            {/*           <div className="row">*/}
            {/*               <div className="col-md-12 my-form-groups   ">*/}
            {/*                   <div className="my-select-style">*/}
            {/*                       <label htmlFor="dd2" className="open-sans-semibold">Страна </label>*/}
            {/*                       <div className="row flex-nowrap m-0 position-relative">*/}
            {/*                           <Select options={data}*/}
            {/*                                   isClearable*/}
            {/*                                   placeholder="Страна"/>*/}
            {/*                           <button className="add-btn"><img src="/img/plus.png" alt="+"/></button>*/}
            {/*                       </div>*/}
            {/*                   </div>*/}
            {/*               </div>*/}
            {/*           </div>*/}
            {/*        </ModalBody>*/}
            {/*        <ModalFooter>*/}
            {/*            <button className="modal-save-btn">Сохранить</button>*/}
            {/*        </ModalFooter>*/}
            {/*    </Modal>*/}
            {/*</>*/}


        </div>
    );
};

export default AddEmployee;