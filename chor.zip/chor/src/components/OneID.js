import React from 'react';

const OneId = () => {
    return (
        <div>
            ONE ID
        </div>
    );
};

export default OneId;