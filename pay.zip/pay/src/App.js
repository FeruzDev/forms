import Login from "./components/Login";
import AddEmployee from "./components/AddEmployee";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import OneId from "./components/OneID";
import FirstEnter from "./mainEnter/FirstEnter";
import SecondEnter from "./mainEnter/SecondEnter";
import ManagementSystemsCertification from "./cerComponents/ManagementSystemsCertification";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Switch>
          <Route path="/" exact component={Login} />
          <Route path="/add-employee" exact component={AddEmployee} />
          <Route path="/first-enter" exact component={FirstEnter} />
          <Route path="/first-enter/second-enter" exact component={SecondEnter} />
          <Route path="/first-enter/second-enter/management-systems-certification" exact component={ManagementSystemsCertification} />

          {/*<Route path"/https://id.egov.uz/?client_id=e_akkred_uz&token_id=808c8a7a-ad7b-45f9-8e23-73d6e1538ff2&method=IDPW" exact component={OneId}/>*/}
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;
